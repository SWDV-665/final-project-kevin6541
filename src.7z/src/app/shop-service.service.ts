import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShopServiceService {

  itemsBrowse = [
    {
      name: 'Toy Car',
      price: '$5.99'
    },
    {
      name: 'Video Game',
      price: '$59.99'
    },
    {
      name: 'Book',
      price: '$14.99'
    },
  ];

  itemsCart = [

  ];
  constructor() {


   }

   moveToCart(item, index){
     this.itemsCart.push(item)
     this.itemsBrowse.splice(index, 1)
   }
   moveToShop(item, index){
    this.itemsBrowse.push(item)
    this.itemsCart.splice(index, 1)
  }

}
