import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import {ShopServiceService} from '../shop-service.service'
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  title = 'Browse';

/*   itemsBrowse = [
    {
      name: 'Toy Car',
      price: '$5.99'
    },
    {
      name: 'Video Game',
      price: '$59.99'
    },
    {
      name: 'Book',
      price: '$14.99'
    },
  ];

  itemsCart = [

  ]; */

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public dataService: ShopServiceService) {

  }
  
  loadItems(){
    return this.dataService.itemsBrowse;
  }


  async addToCart(item, index){
    this.dataService.moveToCart(item, index)
  }

}
