import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import {ShopServiceService} from '../shop-service.service'

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  title = 'Cart';


  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public dataService: ShopServiceService) {

  }

  loadCheckout(){
    return this.dataService.itemsCart;
  }

  async checkout(){
      console.log('Thank you for shopping');
      const toast = await this.toastCtrl.create({
        message: "Thank you for shopping!",
        duration: 3000
      });
      toast.present();
    }

}
