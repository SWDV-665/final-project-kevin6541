import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import {ShopServiceService} from '../shop-service.service'

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})

export class Tab3Page {

  title = 'Cart';


  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public dataService: ShopServiceService) {

  }

  loadCart(){
    return this.dataService.itemsCart;
  }

  async removeFromCart(item, index){
    this.dataService.moveToShop(item, index)
  }

}